module.exports = {
    mongoURL: 
        'mongodb+srv://niudaren:Niudaren1@cluster0.lu3bs.mongodb.net/niudaren?retryWrites=true&w=majority',
    secretOrKey: 'secret'
}